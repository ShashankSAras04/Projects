import { useState } from 'react'
import './App.css'
import Header from './components/Header'
import Firstbody from './components/Firstbody'
import Aboutme from './Aboutme'
import { Serviceoffered } from './components/Serviceoffered'
import Achievements from './components/Achievements'
import Myresume from './components/Myresume'
import Conatact from './components/Conatact'

function App() {


  return (
    <>
      <Header/>
      <Firstbody/>
      <Aboutme/>
      <Serviceoffered/>
      <Achievements/>
      <Myresume/>
      <Conatact/>
    </>
  )
}

export default App
