import React from 'react'

const Aboutme = () => {
  return (
    <div id="aboutme">
      <div className="row justify-content-evenly py-10">
        <h3 className="fw-bold mb-5 mt-5 text-danger" style={{textAlign: "center" }}>About Me</h3>
        <div className="col-md-5">
          <p className='fw-bold'>Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
          <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Explicabo ipsa neque, unde corrupti provident aliquid asperiores nisi temporibus ad magnam perspiciatis non incidunt voluptate doloremque fugiat blanditiis ipsum. Temporibus, ipsa. </p>
          <div className="row mt-3">
            <div className="col-md-4">
              <p className="text-muted">100<br /></p>
              <p className="text-muted">Project Developed<br /></p>
            </div>
            <div className="col-md-4">
              <p className="text-muted">95<br /></p>
              <p className="text-muted">Clients Sastisfied<br /></p>
            </div>
            <div className="col-md-4">
              <p className="text-muted">92<br /></p>
              <p className="text-muted">Feedback<br /></p>
            </div>
          </div>
          <button type="button" className="btn btn-outline-danger" id="home">View CV</button>
        </div>

        <div className="col-md-5">
          <h6>Spring boot</h6>
          <div className="progress mb-4" role="progressbar" aria-label="Example 1px high" aria-valuenow="100"
            aria-valuemin="0" aria-valuemax="100" style={{ height: "12px" }}>
            <div className="progress-bar bg-success" role="progressbar" style={{ width: "25%" }}>25%</div>
          </div>
          <h6>HTML & CSS</h6>
          <div className="progress mb-4" role="progressbar" aria-label="Example 1px high" aria-valuenow="100"
            aria-valuemin="0" aria-valuemax="100" style={{ height: "12px" }}>
            <div className="progress-bar bg-waring" role="progressbar" style={{ width: "50%" }}>50%</div>
          </div>
          <h6>Bootstrap</h6>
          <div className="progress mb-4" role="progressbar" aria-label="Example 1px high" aria-valuenow="100"
            aria-valuemin="0" aria-valuemax="100" style={{ height: "12px" }}>
            <div className="progress-bar bg-danger" role="progressbar" style={{ width: "75%" }}>75%</div>
          </div>
          <h6>JavaScript ES6</h6>
          <div className="progress mb-4" role="progressbar" aria-label="Example 1px high" aria-valuenow="100"
            aria-valuemin="0" aria-valuemax="100" style={{ height: "12px" }}>
            <div className="progress-bar bg-secondary" role="progressbar" style={{ width: "100%" }}>100%</div>
          </div>
          <h6>React JS</h6>
          <div className="progress mb-4" role="progressbar" aria-label="Example 1px high" aria-valuenow="100"
            aria-valuemin="0" aria-valuemax="100" style={{ height: "12px" }}>
            <div className="progress-bar bg-primary" role="progressbar" style={{ width: "80%" }}>80%</div>
          </div>
        </div>
      </div>
    </div>
  )
}

export default Aboutme