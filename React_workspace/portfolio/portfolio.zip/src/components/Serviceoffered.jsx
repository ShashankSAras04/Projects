import React from 'react'

export const Serviceoffered = () => {
    return (
        <div id="service">
            <div className="row justify-content-evenly mb-5">
                <h3 className="fw-bold mb-5 mt-5 text-danger" style={{textAlign: "center" }}>Service Offered</h3>
                <div className="col-md-3 text-center">
                    <div className="card bg-body-tertiary rounded shadow-sm " style={{width: "18rem"}}>
                        <i className="bi bi-code-slash fs-1 text-primary "></i>
                        <div className="card-body">
                            <p className="card-text">Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
                        </div>
                    </div>
                </div>
                <div className="col-md-3 text-center">
                    <div className="card bg-body-tertiary rounded shadow-sm " style={{width: "18rem"}}>
                        <i className="bi bi-front fs-1 text-danger "></i>
                        <div className="card-body">
                            <p className="card-text">Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
                        </div>
                    </div>
                </div>
              <div className="col-md-3 text-center">
                    <div className="card bg-body-tertiary rounded shadow-sm " style={{width: "18rem"}}>
                        <i className="bi bi-database fs-1 text-primary "></i>
                        <div className="card-body">
                            <p className="card-text">Lorem ipsum dolor sit amet consectetur adipisicing elit.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}
