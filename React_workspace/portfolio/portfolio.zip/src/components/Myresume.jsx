import React from 'react'

const Myresume = () => {
  return (
    <div id="myresume"> 
        <h3 className="fw-bold mt-5 text-danger" style={{ textAlign: "center"}}>My Curriculum vitae</h3>
        <p style={{ width: "80%",height: "30%",marginLeft:"150px",textAlign: "justify",lineHeight:"1.8rem",marginBottom:"10px"}}>Lorem ipsum dolor sit, amet consectetur adipisicing elit. Quasi, adipisci praesentium! Facilis nulla adipisci aperiam, 
        eligendi quis impedit. Commodi ad at reprehenderit cupiditate eos, iusto in officiis quod possimus doloremque!
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Repellendus dignissimos architecto sint dolore nisi quis ullam 
        impedit et delectus officia quibusdam ducimus distinctio iste alias voluptas ipsam, eaque porro magni.
        Lorem ipsum dolor sit, amet consectetur adipisicing elit. Quasi, adipisci praesentium! Facilis nulla adipisci aperiam, 
        eligendi quis impedit. Commodi ad at reprehenderit cupiditate eos, iusto in officiis quod possimus doloremque!
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Repellendus dignissimos architecto sint dolore nisi quis ullam 
        impedit et delectus officia quibusdam ducimus distinctio iste alias voluptas ipsam, eaque porro magni.</p>

        <div className="content rounded" style={{ width: "80%",height: "200px",marginLeft:"150px",textAlign:"center", backgroundColor:"#dc3545",border:"1px solid #dc3545",marginTop:"5%",marginBottom:"5%"}}>
            <p className='text-white  mt-5'>
                You would like to do any Project?
            </p>
            <h3 className='fw-bold text-white'>I'm available, I am a Freelancer Full Stack Developer</h3>
        </div>

    </div>


  )
}

export default Myresume