import React from 'react'

const Conatact = () => {
    return (
        <div id="conatact">
            <div className="row rounded shadow-sm row bg-body-tertiary justify-content-evenly mb-5 mx-auto" style={{ width: "80%" }} >
                <div className="col-md-5 mt-3 mb-3">
                    <h6><i className="bi bi-envelope" style={{ textAlign: "left" }}></i>Email</h6>
                    <p>gentech@gmail.com</p>


                    <h6><i className="bi bi-telephone"></i>Phone Number</h6>
                    <p> 080-123456789</p>


                    <h6><i className="bi bi-geo-alt-fill"></i>Address</h6>
                    <p>#555, 7th Phase <br />
                        Attiguppe, 4th Cross <br />
                        Viyanagar, Bangalore</p>
                    <div>
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3888.157917093442!2d77.53079380947906!3d12.96174498729993!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3bae3f0777fcdb13%3A0xe29d677232e1a97f!2sAttiguppe%20Metro%20Entrance(%20towards%20Chandra%20Layout)!5e0!3m2!1sen!2sin!4v1732856510015!5m2!1sen!2sin" style={{ width: "300", height: "150", border: "0" }} allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                    </div>
                </div>
                <div className="col-md-5">
                    <form>
                        <div class="mb-3">
                            <label for="fullName" className="form-label">Full Name</label>
                            <input type="text" className="form-control" id="fullName" />
                        </div>
                        <div class="mb-3">
                            <label for="exampleInputEmail1" className="form-label">Email address</label>
                            <input type="email" className="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" />
                        </div>
                        <div class="mb-3">
                            <label for="contact" className="form-label">Phone Number</label>
                            <input type="text" className="form-control" id="contact" />
                        </div>
                        <div class="mb-3">
                            <label for="exampleFormControlTextarea1" className="form-label">Message</label>
                            <textarea className="form-control exampleFormControlTextarea1" rows={3}></textarea>
                        </div>
                        <button type="submit" class="btn btn-primary">Submit</button>
                    </form>
                </div>
            </div>

            <div className="container-fluid">
                <div className="row" style={{ position: "fixed", backgroundColor: "grey", width: "100%",bottom:"0",textAlign:"center",padding:"3px 0" }}>
                    <span class="footer text-danger">Copy Right@2024 All rights Reserved</span>
                </div>
            </div>
        </div>
    )
}

export default Conatact