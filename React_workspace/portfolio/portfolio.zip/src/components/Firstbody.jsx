import React from 'react'
import pf from './../assets/image/pic.jpg'

const Firstbody = () => {
    return (
        <div id="home">
            <div className="row justify-content-evenly m-5">
                <div className="col-md-5">
                        <h3 className="fw-bold text-danger">Hello I'm<br /></h3>
                        <h3 className="fw-bold text-danger">Shashank S<br /></h3>
                        <h3 className="fw-bold text-danger">Full Stack Developer<br /></h3>
                    <p className="text-muted" style={{textAlign:"justify"}}>Lorem ipsum dolor sit amet consectetur adipisicing elit. Mollitia, eius voluptate! Harum ducimus placeat rerum dignissimos aspernatur repudiandae praesentium numquam!<br /> Tenetur pariatur cupiditate, quisquam sequi ipsam fugiat quam illo placeat.Lorem ipsum dolor sit amet consectetur adipisicing elit. Quia ipsa ratione maiores! Dolore, atque quidem quibusdam praesentium doloremque dicta maiores eaque,<br /> magnam sit facere delectus tempora laboriosam, quas nobis reiciendis?</p>
                    <button type="button" class="btn btn-outline-danger" id="myresume">View CV</button>
                </div>
                <div className="col-md-5">
                    <img src={pf} className='img-fluid rounded-circle d-block ms-auto' style={{ width: "400px", height: "400px", objectFit: "cover" }} alt="" />
                </div>
            </div>


        </div>
    )
}

export default Firstbody