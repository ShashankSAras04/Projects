import React from 'react'

const Goodmorning = () => {
  return (
    <div>Hello</div>
  )
}

export default Goodmorning