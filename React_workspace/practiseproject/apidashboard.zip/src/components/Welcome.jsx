import React from "react";
 function Welcome(){
    return(
        <h1>Welcome to React</h1>
    )
 }
 export default Welcome